public class BankDriver {
    public static void main(String[] args){
        // 사람 선언 --- 1
        Person p1 = new Person();
        p1.name = "조연아";
        p1.age = 30;
        p1.cashAmount  = 100000;

        // 은행계좌 생성
        BankAccount acc1 = new BankAccount();
        acc1.balance = 100000;

        // p1과 acc1 인스턴스끼리 엮어주기
        p1.account = acc1;
        acc1.owner = p1;

        System.out.println(p1.account.balance);
        System.out.println(acc1.owner.name);

        // 사람선언2
        Person p2 = new Person();
        p2.name = "yuna2";
        p2.age = 30;
        p2.cashAmount = 100000;


        // 은행계좌선언2
        BankAccount acc2 = new BankAccount();
        acc2.balance = 500000;
        
        // 인스턴스 엮어주기
        p2.account = acc2;
        acc2.owner = p2;

        // 30,000원 입금
        acc2.deposit(30000);

        // 170,000원 출금
        acc2.withdraw(1700000);

        // 620,000원 입금
        acc2.deposit(620000);

        // 890,000원 출금
        acc2.withdraw(890000);







    }
}

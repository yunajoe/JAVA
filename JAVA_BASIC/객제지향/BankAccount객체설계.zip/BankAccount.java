public class BankAccount {
    int balance;
    Person owner; // Person class를 자료형으로 받는다
    // 1. 입금 method
    // parameter: 입금할 액수(int)
    // 리턴: 성공여부(boolean)
      boolean deposit(int amount) {
        if(amount < 0 || owner.cashAmount < amount){
            System.out.println("입금실패입니다.잔고:"+balance+ "원. 현금" + owner.cashAmount);
            return false;
        } else{
            balance = balance-amount; // 잔고
            owner.cashAmount = owner.cashAmount + amount; // 계좌의 현금액
            System.out.println(amount + "원 입금하셨습니다. 잔고:" + balance + "원, 현금:" + owner.cashAmount);
            return true;
        }
      }
     // 2.출금 method
     // parameter: 출금할 액수(int)
     // 리턴: 성공여부(boolean)
    boolean withdraw(int amount){
        if(amount < 0 || amount > balance){
            System.out.println("출금실패입니다. 잔고:" + balance + "원, 현금:" + owner.cashAmount);
            return false;
        }else{
            balance = balance-amount;
            owner.cashAmount = owner.cashAmount + amount;
            System.out.println(amount + "원 출금하였습니다. 잔고:" + balance + "원, 현금" + owner.cashAmount);
            return true;
        }
    }

}

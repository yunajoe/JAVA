public class Person {
    String name;
    int age;
    int cashAmount;
    BankAccount account; // Bankaccount를 자료형으로 받는다

}
